This python module loads an xdf file and replays it to an LSL stream.

Installation (from Terminal):
cd <path_to_'replay_stream'>
pip install -e .

Usage (from Terminal):
python -m replay --file <path_to_xdf_file>

note that this has only been tested for eego EEG data and does currently not work for multiple streams.
