from distutils.core import setup


setup(
    name='replay_stream',
    version='0.0.1',
    description='Toolbox to replay xdf data into LSL streams.',
    long_description='A Python Toolbox to stream eego with LSL',
    author='Marius Keute',
    author_email='marius.keute@uni-tuebingen.de',
    packages=['replay'],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console',
        'Intended Audience :: Developers',
        'Intended Audience :: Education',
        'Intended Audience :: Healthcare Industry',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Information Technology',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Topic :: Scientific/Engineering :: Human Machine Interfaces',
        'Topic :: Scientific/Engineering :: Medical Science Apps.',
        'Topic :: Software Development :: Libraries',
        ]
)
