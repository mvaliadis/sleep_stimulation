# -*- coding: utf-8 -*-
"""
Created on Mon May 13 17:13:27 2019

@author: Robert Guggenberger
"""
from replay.replay_streamer import Outlet

# %%
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Replay xdf data with LSL')
    parser.add_argument('--file', type=str, default= '',
                        help='''xdf file to be replayed ''')
    
    args = parser.parse_args()                     

    outlet = Outlet(args.file)
    outlet.start()

           
