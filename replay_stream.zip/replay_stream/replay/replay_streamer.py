# -*- coding: utf-8 -*-
"""
Created on Mon May 13 16:19:32 2019

@author: MessPC
"""
from pylsl import StreamInfo, StreamOutlet, local_clock
import time
import threading
import pyxdf
import numpy as np
from reiz import clock
import pyxdf
# %%


# %%



class Outlet(threading.Thread):
    
    def __init__(self, xdffile):
        threading.Thread.__init__(self)
        tmpdat = pyxdf.load_xdf(xdffile)
        self.dat, self.fs, chan_names = self.get_data(tmpdat)
        self.streamix = 0
        chancount = len(chan_names)
        self.info = StreamInfo(name='eeg_replay', type='EEG', 
                               channel_count = chancount, 
                               nominal_srate= self.fs, 
                               channel_format='float32')
    
        # append some meta-data
        channels = self.info.desc().append_child("channels")
        for c in chan_names:
            channels.append_child("channel") \
                .append_child_value("label", c) \
                .append_child_value("unit", "microvolts") \
                .append_child_value("type", "EEG")
    
    def get_data(self, tmpdat):
        dat = tmpdat[0][0]['time_series']
        fs = int(tmpdat[0][0]['info']['nominal_srate'][0])
        chan_names = [tmpdat[0][0]['info']['desc'][0]['channels'][0]['channel'][ix]['label'][0] for ix in range(len(tmpdat[0][0]['info']['desc'][0]['channels'][0]['channel']))]
        return dat, fs, chan_names
     
    def pull_data(self):
        if len(np.shape(self.dat)) == 1:            
            smpl = [self.dat[self.streamix]]
        else:
            smpl = self.dat[self.streamix,:]
        self.streamix += 1
        return smpl 
        
    def run(self):
        outlet = StreamOutlet(self.info)
        self.is_running = True
        counter = 0.
        chan_count = self.info.channel_count()  
        nominal_srate = self.info.nominal_srate()  
        print(self.info.as_xml())
        while self.streamix < len(self.dat):#self.is_running:
            clock.tick()
            data = self.pull_data()
            sample_count= 1
            counter += sample_count                       
            chunk = []
            for sample_idx in range(sample_count):
                sample = []
                for chan_idx in range(chan_count):
                    sample.append(data[chan_idx])
                chunk.append(sample)
            
            outlet.push_chunk(chunk)

            clock.sleep_debiased(1/self.fs)
            
            if counter>nominal_srate:
                counter = 0
                print('Example sample:', ['{:3.2f}'.format(s) for s in data], 'at', clock.now())
                


